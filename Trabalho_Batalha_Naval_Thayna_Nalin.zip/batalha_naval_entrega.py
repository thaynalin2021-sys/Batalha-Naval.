
import random

# -----------------------------------------------------
# 🎯 Jogo de Batalha Naval - Versão para entrega
# Autor: Thayna Nalin (adaptado)
# Curso: Análise e Desenvolvimento de Sistemas - Estácio
# Data: 14/11/2025
# -----------------------------------------------------
# Instruções:
# - Execute este arquivo com Python 3.8+.
# - Escolha o tamanho do tabuleiro, quantidade de navios e tentativas.
# - Insira coordenadas no formato numérico (linha e coluna).
# -----------------------------------------------------

def criar_tabuleiro(tamanho):
    """Cria um tabuleiro quadrado com o símbolo '~' representando água."""
    return [["~"] * tamanho for _ in range(tamanho)]

def mostrar_tabuleiro(tabuleiro, mostrar_navios=False, navios=None):
    """Exibe o tabuleiro no console.
    Se mostrar_navios for False, os navios não são mostrados (para o jogador).
    """
    tamanho = len(tabuleiro)
    header = "   " + " ".join(f"{i:2}" for i in range(tamanho))
    print(header)
    for i, linha in enumerate(tabuleiro):
        display = []
        for j, cel in enumerate(linha):
            if cel == "N" and not mostrar_navios:
                display.append("~")  # esconder navios durante o jogo
            else:
                display.append(cel)
        print(f"{i:2} " + " ".join(f"{c:2}" for c in display))
    print()

def posicionar_navios(tabuleiro, quantidade):
    """Posiciona navios (tamanho 1) em posições únicas aleatórias."""
    tamanho = len(tabuleiro)
    navios = set()
    while len(navios) < quantidade:
        linha = random.randint(0, tamanho - 1)
        coluna = random.randint(0, tamanho - 1)
        navios.add((linha, coluna))
    return navios

def solicitar_inteiro(prompt, minimo, maximo, padrão=None):
    """Lê um inteiro do usuário com validação e opção de padrão (enter)."""
    while True:
        entrada = input(prompt).strip()
        if entrada == "" and padrão is not None:
            return padrão
        try:
            x = int(entrada)
            if x < minimo or x > maximo:
                print(f"⚠️ Informe um número entre {minimo} e {maximo}.")
                continue
            return x
        except ValueError:
            print("⚠️ Entrada inválida. Digite um número inteiro.")

def jogar_batalha_naval():
    print("🌊 BEM-VINDO AO JOGO BATALHA NAVAL 🌊\n")
    print("Dicas: pressione Enter para aceitar o valor padrão entre parênteses.\n")

    tamanho = solicitar_inteiro("Tamanho do tabuleiro (padrão 5): ", 3, 12, 5)
    max_navios = min( (tamanho*tamanho)//2, tamanho*2 )
    quantidade_navios = solicitar_inteiro(f"Quantidade de navios (padrão 3, máximo {max_navios}): ", 1, max_navios, 3)
    tentativas = solicitar_inteiro(f"Tentativas permitidas (padrão {(tamanho*tamanho)//3}): ", 1, tamanho*tamanho, max(1, (tamanho*tamanho)//3))

    tabuleiro = criar_tabuleiro(tamanho)
    navios = posicionar_navios(tabuleiro, quantidade_navios)
    # marca navios internamente para facilitar exibição final
    for (r,c) in navios:
        tabuleiro[r][c] = "N"

    acertos = 0
    tentativas_restantes = tentativas
    posições_testadas = set()

    while tentativas_restantes > 0 and acertos < quantidade_navios:
        mostrar_tabuleiro(tabuleiro, mostrar_navios=False, navios=navios)
        print(f"Tentativas restantes: {tentativas_restantes}   Navios restantes: {quantidade_navios - acertos}\n")

        linha = solicitar_inteiro(f"Digite a linha (0 a {tamanho-1}): ", 0, tamanho-1)
        coluna = solicitar_inteiro(f"Digite a coluna (0 a {tamanho-1}): ", 0, tamanho-1)

        if (linha, coluna) in posições_testadas:
            print("⚠️ Você já tentou essa posição. Tente outra.\n")
            continue

        posições_testadas.add((linha, coluna))

        if (linha, coluna) in navios:
            print("💥 ACERTOU! Um navio foi atingido!\n")
            tabuleiro[linha][coluna] = "✓"
            acertos += 1
        else:
            print("💦 Errou! Água!\n")
            tabuleiro[linha][coluna] = "X"

        tentativas_restantes -= 1

    # Mostrar resultado final
    if acertos == quantidade_navios:
        print("🎉 PARABÉNS! Você afundou todos os navios!")
    else:
        print("😢 Fim de jogo! Você não conseguiu afundar todos os navios.")

    print("\nTabuleiro final (N = navio, ✓ = navio atingido, X = tiro na água):")
    # exibir navios agora
    mostrar_tabuleiro(tabuleiro, mostrar_navios=True, navios=navios)
    print("🏁 Jogo encerrado!\n")

def main():
    while True:
        jogar_batalha_naval()
        opc = input("Deseja jogar novamente? (s/n) ").strip().lower()
        if opc and opc[0] == "s":
            print("\n\n")
            continue
        else:
            print("Até a próxima! 👋")
            break

if __name__ == "__main__":
    main()
